import type { HostStateStore } from './host-state.js';
export declare const DELTA_STATE_PATH = "/api/delta-desktop/state";
export declare const DELTA_SESSION_LOCK_PATH = "/api/delta-desktop/session-lock";
export declare const DELTA_SESSION_MOVE_PATH = "/api/delta-desktop/session-move";
export declare const DELTA_SESSION_DELETE_PATH = "/api/delta-desktop/session-delete";
export declare const DELTA_SESSION_DELETE_UNGROUPED_PATH = "/api/delta-desktop/session-delete-ungrouped";
interface SessionOpsHostContext {
    get?(name: string): unknown;
    inject?(deps: string[], cb: (scope: any) => void | (() => void)): unknown;
}
export declare function installHostSessionOps(ctx: SessionOpsHostContext, store: HostStateStore, hooks?: {
    onSessionChanged?: (sessionId: string) => void;
}): () => void;
export {};
