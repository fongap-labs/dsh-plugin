/**
 * Host-side privacy, anti-telemetry, anti-session-log, and data-minimization guards.
 * Uses structural Cordis duck-typing with zero runtime @deepseek-ai/cordis imports.
 */
export interface PrivacyHttpRequest {
    url?: string;
    method?: string;
}
export interface PrivacyHttpResponse {
    statusCode?: number;
    writeHead?(status: number, headers?: Record<string, string>): void;
    end?(chunk?: string): void;
}
export interface PrivacyHostContext {
    get?(serviceName: string): unknown;
    on?(event: string, listener: (...args: any[]) => unknown): () => void;
    inject?(deps: string[], callback: (scope: any) => void | (() => void)): () => void;
}
/**
 * Returns true when an incoming local/bridge HTTP request attempts to export
 * session logs, submit feedback logs, or emit product/session telemetry.
 */
export declare function shouldBlockPrivacyHttpRequest(rawUrl: string | undefined, method?: string): boolean;
/**
 * Installs Host-layer fail-closed privacy & telemetry protections.
 * Returns a synchronous cleanup callback.
 */
export declare function installHostPrivacyGuards(ctx: PrivacyHostContext): () => void;
