export declare const DELTA_SESSION_SEARCH_PATH = "/api/delta-desktop/session-search";
export interface SessionTextBlock {
    seq: number;
    turn: number;
    role: 'user' | 'assistant';
    text: string;
}
export interface HostSessionSearchHit {
    sessionId: string;
    title: string;
    snippet: string;
    matchStart: number;
    matchEnd: number;
    seq?: number;
    turn?: number;
    role?: 'user' | 'assistant';
    updatedAt: number;
    workspaceId?: string;
    score: number;
}
export interface HostSearchResponsePayload {
    items: HostSessionSearchHit[];
    truncated: boolean;
    redacted: true;
}
interface SessionSummary {
    sessionId: string;
    title: string;
    workspaceId?: string;
    updatedAt: number;
}
interface SearchHostContext {
    get?(serviceName: string): unknown;
    inject?(deps: string[], callback: (scope: any) => void | (() => void)): () => void;
}
interface SessionEventLike {
    seq?: number;
    type?: string;
    payload?: {
        source?: {
            kind?: string;
        };
        content?: Array<{
            type?: string;
            text?: string;
        }>;
    };
}
/**
 * Extracts redacted conversation blocks from raw session log events.
 * Strictly skips internal tool/system debug dumps so raw Session Logs are never exposed.
 */
export declare function extractConversationBlocks(events: readonly SessionEventLike[] | undefined): SessionTextBlock[];
/**
 * Scores a session's title + redacted blocks against a query and produces a redacted hit if matched.
 */
export declare function scoreAndExtractSessionHit(rawQuery: string, meta: SessionSummary, blocks: readonly SessionTextBlock[]): HostSessionSearchHit | undefined;
/**
 * Installs the in-memory Host session search HTTP handler (`/api/delta-desktop/session-search`).
 * Returns a cleanup callback that clears the in-memory LRU cache immediately.
 */
export declare function installHostSessionSearch(ctx: SearchHostContext, options?: {
    isExcluded?: (sessionId: string) => boolean;
    registerInvalidator?: (fn: (sessionId: string) => void) => void;
}): () => void;
export {};
