/**
 * Request-local, reversible masking for text that is about to cross an LLM
 * provider boundary. Original message history remains Host-owned and local.
 */
export interface SensitiveRedactor {
    redact(text: string): string;
    restore(text: string): string;
    safePrefixLength(text: string): number;
    hasMatches(): boolean;
}
export declare function createSensitiveRedactor(): SensitiveRedactor;
export interface TextContentBlock {
    type: 'text' | 'reasoning';
    text: string;
    [key: string]: unknown;
}
export interface ToolCallContentBlock {
    type: 'tool-call';
    arguments: string;
    [key: string]: unknown;
}
export interface RequestMessage {
    role: string;
    content?: readonly Record<string, unknown>[];
    [key: string]: unknown;
}
export interface ModelRequest {
    messages: readonly RequestMessage[];
    system?: string;
    tools?: readonly Record<string, unknown>[];
    [key: string]: unknown;
}
/** Redact model-visible text while preserving binary attachment references. */
export declare function redactModelRequest<T extends ModelRequest>(request: T, redactor: SensitiveRedactor): T;
export interface StreamChunkLike {
    type: string;
    index?: number;
    text?: string;
    argumentsDelta?: string;
    block?: Record<string, unknown>;
    [key: string]: unknown;
}
/** Preserve streaming while holding only the possible tail of a split marker. */
export declare function restoreStream<T extends StreamChunkLike>(source: AsyncIterable<T>, redactor: SensitiveRedactor): AsyncIterable<T>;
