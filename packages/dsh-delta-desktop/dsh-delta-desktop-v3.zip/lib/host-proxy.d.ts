import type { HostStateStore, ProxyMode, ProxySettings } from './host-state.js';
export declare const DELTA_PROXY_PATH = "/api/delta-desktop/proxy";
export interface EffectiveProxyState {
    mode: ProxyMode;
    source: 'system-env' | 'system-registry' | 'direct' | 'manual';
    httpProxy?: string;
    httpsProxy?: string;
    noProxy: string;
}
interface ProxyHostContext {
    get?(name: string): unknown;
    inject?(deps: string[], cb: (scope: any) => void | (() => void)): () => void;
}
export declare function validateProxyUrl(raw: string): {
    ok: true;
    normalized: string;
} | {
    ok: false;
    reason: 'invalid' | 'socks' | 'scheme';
};
export declare function mergeLoopbackNoProxy(rawNoProxy: string): string;
export declare function parseWindowsProxyServer(rawServer: string, overrideStr?: string): {
    httpProxy?: string;
    httpsProxy?: string;
    noProxy: string;
};
export declare function installHostProxyManager(ctx: ProxyHostContext, store: HostStateStore, options?: {
    resolveSystemRegistryProxy?: () => Promise<{
        httpProxy?: string;
        httpsProxy?: string;
        noProxy: string;
    } | undefined>;
}): {
    applySettings: (settings: ProxySettings) => Promise<EffectiveProxyState>;
    getEffective: () => EffectiveProxyState;
    dispose: () => Promise<void>;
};
export {};
