export type VisionProtocol = 'openai' | 'anthropic' | 'ollama';
export interface VisionImage {
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
    data: Uint8Array;
}
export interface CustomVisionConfig {
    protocol: VisionProtocol;
    baseURL: string;
    model: string;
    maxTokens: number;
}
/** Make one bounded image-description request using a compatible protocol. */
export declare function requestVisionDescription(config: CustomVisionConfig, image: VisionImage, prompt: string, credential: string | undefined, fetcher?: typeof fetch, signal?: AbortSignal): Promise<string>;
export declare function isValidCredentialRef(value: string): boolean;
