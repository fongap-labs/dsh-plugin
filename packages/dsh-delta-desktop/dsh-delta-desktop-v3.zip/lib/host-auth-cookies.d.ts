interface HttpRequestLike {
    headers?: Record<string, string | string[] | undefined>;
}
interface HttpResponseLike {
    writeHead?: (...args: unknown[]) => unknown;
    getHeader?(name: string): string | number | readonly string[] | undefined;
    setHeader?(name: string, value: string | readonly string[]): unknown;
}
interface WebServerLike {
    readonly server?: {
        prependListener?: (event: 'request', listener: (req: HttpRequestLike, res: HttpResponseLike) => void) => unknown;
        off?: (event: 'request', listener: (req: HttpRequestLike, res: HttpResponseLike) => void) => unknown;
    };
    getOrigin?: () => string;
}
interface HostCookieContext {
    inject?: (deps: string[], callback: (ctx: HostCookieContext & {
        webServer?: WebServerLike;
    }) => void | (() => void)) => (() => void) | void;
    effect?: (callback: () => (() => void) | void, label?: string) => (() => void) | void;
}
export declare function computeCurrentAuthCookieName(origin: string): Promise<string | undefined>;
/** Extract unique `dsh-auth-*` cookie names in the order they appear in a `Cookie` header. */
export declare function parseAuthCookieNames(cookieHeader: string | undefined): string[];
/**
 * Keep the current launch's auth cookie plus at most `maxKeptOther` recent sibling cookies.
 * Returning only the oldest excess names prevents Chromium's `127.0.0.1` cookie jar from
 * growing past Node's 16 KiB `maxHeaderSize` across restarts.
 */
export declare function selectStaleAuthCookieNames(names: readonly string[], currentCookieName?: string, maxKeptOther?: number): string[];
/**
 * Automatically expire excess accumulated `dsh-auth-*` loopback cookies via HTTP `Set-Cookie`
 * responses so Electron `net.fetch` requests never exceed Node's 16 KiB request header cap.
 */
export declare function installHostAuthCookiePruner(ctx: HostCookieContext, maxKeptOther?: number): () => void;
export {};
