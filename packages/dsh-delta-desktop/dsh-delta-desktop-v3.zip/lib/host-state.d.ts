/**
 * Host-local state persistence for @fongap-labs/dsh-delta-desktop.
 * Stores hashed session-lock PIN (scrypt), locked/moved/deleted session state,
 * and network proxy configuration in the active profile directory.
 * Never exports secret hashes to the Client and keeps zero static node:* imports
 * to stay compatible with `tsconfig.json` `"types": []`.
 */
export type ProxyMode = 'system' | 'direct' | 'manual';
export interface ProxySettings {
    mode: ProxyMode;
    httpProxy: string;
    httpsProxy: string;
    noProxy: string;
}
export interface PinHashRecord {
    salt: string;
    hash: string;
}
export interface DeltaHostState {
    pinHash?: PinHashRecord;
    totpSecret?: string;
    lockedSessionIds: string[];
    movedSessions: Record<string, string>;
    deletedSessionIds: string[];
    proxy: ProxySettings;
}
export type SessionLockMode = 'totp' | 'pin' | 'none';
export interface PublicDeltaHostState {
    hasPin: boolean;
    lockMode: SessionLockMode;
    lockedSessionIds: string[];
    movedSessions: Record<string, string>;
    deletedSessionIds: string[];
    proxy: ProxySettings;
}
export declare function loadNodeModule<T = any>(specifier: string): Promise<T>;
export declare function defaultProxySettings(): ProxySettings;
export declare function normalizeDeltaState(raw: unknown): DeltaHostState;
export declare function toPublicHostState(state: DeltaHostState): PublicDeltaHostState;
export declare function normalizeBase32Secret(input: string): string | undefined;
export declare function base32Encode(bytes: Uint8Array): string;
export declare function base32Decode(secret: string): Uint8Array;
export declare function isSixDigitCode(code: unknown): code is string;
export declare function generateTotpSecret(byteLength?: number): Promise<string>;
export declare function buildOtpAuthUri(secret: string, account?: string, issuer?: string): string;
export declare function generateTotpCode(secret: string, timeMs?: number, periodSeconds?: number, digits?: number): Promise<string>;
export declare function verifyTotpCode(secret: string, code: string, windowSteps?: number, timeMs?: number, periodSeconds?: number): Promise<boolean>;
export declare function hashPinSecret(pin: string): Promise<PinHashRecord>;
export declare function verifyPinSecret(pin: string, record: PinHashRecord | undefined): Promise<boolean>;
export interface HostStateStore {
    resolvePath(): Promise<string>;
    read(): Promise<DeltaHostState>;
    update(mutator: (current: DeltaHostState) => DeltaHostState | Promise<DeltaHostState>): Promise<DeltaHostState>;
    getCached(): DeltaHostState;
}
export declare function resolveDshHome(ctx?: {
    get?(name: string): unknown;
}): Promise<string>;
export declare function createHostStateStore(ctx: {
    get?(name: string): unknown;
}): HostStateStore;
export declare function makeJsonResponse(status: number, payload: unknown): unknown;
export declare function readRequestJson(request: unknown): Promise<Record<string, unknown>>;
