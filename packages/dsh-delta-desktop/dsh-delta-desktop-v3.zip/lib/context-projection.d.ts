import { z } from 'zod';
export interface CompactionStatus {
    seq: number;
    phase: 'idle' | 'running' | 'completed' | 'failed';
    failed: boolean;
    shadowedTokenCount?: number;
}
export interface CompactionEvent {
    type: string;
    seq: number;
    data?: unknown;
}
export declare const EMPTY_COMPACTION_STATUS: CompactionStatus;
/** Project the latest durable compaction lifecycle for a chat activity indicator. */
export declare function foldCompactionStatus(state: CompactionStatus, event: CompactionEvent): CompactionStatus;
export declare const compactionStatusProjection: {
    key: string;
    stateSchema: z.ZodObject<{
        seq: z.ZodNumber;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            idle: "idle";
            running: "running";
        }>;
        failed: z.ZodBoolean;
        shadowedTokenCount: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>;
    stateVersion: number;
    init: () => CompactionStatus;
    apply: typeof foldCompactionStatus;
    wire: {
        viewSchema: z.ZodObject<{
            seq: z.ZodNumber;
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                idle: "idle";
                running: "running";
            }>;
            failed: z.ZodBoolean;
            shadowedTokenCount: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>;
        view: (state: CompactionStatus) => CompactionStatus;
    };
};
interface ProjectionHandle {
    dispose(): Promise<void>;
}
interface ProjectionRegistry {
    register(definition: unknown): Promise<ProjectionHandle>;
}
interface ProjectionContext {
    sessionProjections?: ProjectionRegistry;
    logger?: {
        warn?(message: string): void;
    };
}
/** Register an optional client-readable projection; older Hosts keep working without it. */
export declare function registerCompactionStatusProjection(ctx: {
    inject(services: string[], callback: (child: ProjectionContext) => void): void;
    logger?: {
        warn?(message: string): void;
    };
}): () => void;
export {};
