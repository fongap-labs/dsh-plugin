/**
 * Delta Host capability contract v1.
 * Only explicit, versioned Host declarations grant an integration capability.
 * Host version strings, private DOM and method names are never evidence.
 */
export declare const DELTA_HOST_CONTRACT_VERSION: 1;
export declare const DELTA_HOST_CAPABILITIES: readonly ['theme.tokens', 'settings.section', 'sidebar.brand', 'sidebar.compose', 'workspace.initial-collapse', 'workspace.before-delete', 'session.row', 'conversation.status', 'conversation.transport', 'conversation.stream', 'conversation.stop', 'approval.request'];
export type DeltaHostCapability = typeof DELTA_HOST_CAPABILITIES[number];
export type DeltaCapabilityManifest = Readonly<{
    contractVersion: number;
    capabilities: readonly string[];
}>;
export type DeltaCapabilityReport = Readonly<{
    compatible: boolean;
    available: readonly DeltaHostCapability[];
    missing: readonly DeltaHostCapability[];
    reason: 'ready' | 'missing-manifest' | 'unsupported-contract' | 'missing-capabilities';
}>;
export declare function negotiateHostCapabilities(manifest: DeltaCapabilityManifest | null | undefined, required: readonly DeltaHostCapability[]): DeltaCapabilityReport;
