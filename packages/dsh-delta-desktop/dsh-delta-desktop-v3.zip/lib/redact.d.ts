/**
 * Privacy-preserving data minimization & redaction utilities.
 * Strips sensitive tokens, credentials, PII, and OS usernames before indexing
 * or rendering in local search UI. Zero external runtime imports.
 */
/**
 * Redacts OS user home folder names while keeping project relative segments readable.
 */
export declare function redactPathForUi(input: string): string;
/**
 * Redacts private blocks, credentials, tokens, emails, phone numbers, and OS usernames.
 */
export declare function redactSensitiveText(input: string): string;
