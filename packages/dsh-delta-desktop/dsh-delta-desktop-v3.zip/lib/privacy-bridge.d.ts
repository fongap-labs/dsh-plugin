import { type VisionProtocol } from './vision-protocol.js';
import Schema from '@deepseek-ai/schemastery';
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    deepSeekModelsEnabled: Schema<boolean, boolean, "defined">;
    redactionEnabled: Schema<boolean, boolean, "defined">;
    visionEnabled: Schema<boolean, boolean, "defined">;
    visionSource: Schema<"custom" | "existing", "custom" | "existing", "defined">;
    visionProvider: Schema<string, string, "defined">;
    visionModel: Schema<string, string, "defined">;
    visionProtocol: Schema<"anthropic" | "ollama" | "openai", "anthropic" | "ollama" | "openai", "defined">;
    visionBaseURL: Schema<string, string, "defined">;
    visionCustomModel: Schema<string, string, "defined">;
    visionCredentialRef: Schema<string, string, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    deepSeekModelsEnabled: Schema<boolean, boolean, "defined">;
    redactionEnabled: Schema<boolean, boolean, "defined">;
    visionEnabled: Schema<boolean, boolean, "defined">;
    visionSource: Schema<"custom" | "existing", "custom" | "existing", "defined">;
    visionProvider: Schema<string, string, "defined">;
    visionModel: Schema<string, string, "defined">;
    visionProtocol: Schema<"anthropic" | "ollama" | "openai", "anthropic" | "ollama" | "openai", "defined">;
    visionBaseURL: Schema<string, string, "defined">;
    visionCustomModel: Schema<string, string, "defined">;
    visionCredentialRef: Schema<string, string, "defined">;
}>>, "plain">;
type Volatile<T> = T | {
    get(): T;
};
export interface DeltaPrivacyConfig {
    deepSeekModelsEnabled: Volatile<boolean>;
    redactionEnabled: Volatile<boolean>;
    visionEnabled: Volatile<boolean>;
    visionSource: Volatile<'existing' | 'custom'>;
    visionProvider: Volatile<string>;
    visionModel: Volatile<string>;
    visionProtocol: Volatile<VisionProtocol>;
    visionBaseURL: Volatile<string>;
    visionCustomModel: Volatile<string>;
    visionCredentialRef: Volatile<string>;
}
type ImageRef = {
    attachmentId: string;
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
    [key: string]: unknown;
};
type ContentBlock = Record<string, any>;
type LlmRequest = {
    provider: string;
    model: string;
    messages: Array<{
        role: string;
        content: ContentBlock[];
        [key: string]: any;
    }>;
    signal?: AbortSignal;
    sessionId?: string;
    [key: string]: any;
};
type LlmChunk = {
    type: string;
    text?: string;
    reason?: {
        kind?: string;
        failure?: {
            code?: string;
            message?: string;
        };
    };
    [key: string]: any;
};
type ModelInfo = {
    id: string;
    inputModalities?: readonly string[];
};
type LlmService = {
    listModels?(provider: string, ...args: unknown[]): Promise<readonly ModelInfo[]> | readonly ModelInfo[];
    resolveModelInfo?(provider: string, model: string, signal?: AbortSignal): Promise<Record<string, any>>;
    stream(options: LlmRequest): AsyncIterable<LlmChunk>;
};
type AttachmentsService = {
    readImage(ref: ImageRef): Promise<{
        ref: ImageRef;
        data: Uint8Array;
    }>;
};
type CredentialsService = {
    resolve(ref: string): Promise<{
        value: string;
    } | undefined>;
};
type HostContext = {
    inject(services: string[], callback: (scope: HostContext & {
        llm?: LlmService;
        attachments?: AttachmentsService;
        credentials?: CredentialsService;
    }) => void): void;
    on(event: 'llm/stream', listener: (options: LlmRequest, next: () => AsyncIterable<LlmChunk>) => AsyncIterable<LlmChunk>): unknown;
    effect?(callback: () => void | (() => void), label?: string): void;
    logger?: {
        warn?(message: string): void;
    };
    llm?: LlmService;
    attachments?: AttachmentsService;
    credentials?: CredentialsService;
};
/** Register reversible egress masking and the text-model vision bridge. */
export declare function registerPrivacyBridge(ctx: HostContext, config: DeltaPrivacyConfig): () => void;
export {};
